This MATLAB code is to accompany our manuscript, ``Topography-albedo feedback and the shifting Arctic ice pack".

To run the version of the code used in the manuscript to produce all data, open run_model.m, and press "run".
Physical parameters are hard-coded. It requires MATLAB's symbolic toolbox. If you have access to MATLAB's parallel computing
toolbox, you could use run_model_parallel.m, which is a parallelized version of the code intended for use on HPC
resources.

To run the demonstration version of the code, open run_model_DEMO.m, and press "run". This is simply a version of
run_model.m on a smaller domain with a smaller run-time.

Functions called from within run_model.m (and its variants) are commented.

In the accompanying "TAFfigures06182025.zip", you will find the scripts used for processing and visualizing
the data produced by run_model.m.