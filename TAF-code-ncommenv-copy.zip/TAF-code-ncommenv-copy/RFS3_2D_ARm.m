%function [z,Off,Coef]=RFS3_2D_ARm(p, b, r) % Create Topography from Brady Bowen code
function z=RFS3_2D_ARm(p, b, r) % Create Topography from Brady Bowen code

%  p_1, p_2 ~ 0.4 +- 0.1
% [z,Off,Coef]=RFS3_2D_ARm(p,flag1)
%
%   Creates a Fourier Surface with various properties.
%   Currently generating the surface using anisotropic
%   red noise as the cosine coefficients.
%
% Inputs:
%   p=[p_1,p_2]: Two dimensional vector of red noise constants, real numbers in the range [0,1)
%   flag1 =1 saves levelsets to 'levelset' folder in current path
%         =0 do not save levelsets (default)
%
%   More options are in the preamble of the code.
%
% Outputs:
%   z: Generated surface
%   Off: The matrix of phase angles used
%   Coef: The matrix of coefficients used

syms x y;

n = 20; %Resolution of cosine terms, gives 2n+1 x n+1 terms
%r = r; %Resolution of Surface

%Offset (or phase angle) matrix
% rng(1); 
Off=rand(2*n+1,n+1)*2*pi;
%Off=zeros(2*n+1,n+1);

%Red noise amplitude generator 2
s=1/n;
[coefn,coefm]=meshgrid(0:s:1,-1:s:1);

Lh = sqrt(1./(   (1+p(1)^2-2*p(1)*cos(pi*coefn) )   .*(1+p(2)^2-2*p(2)*cos(pi*coefm))       )              );
Lh(n+1:2*n+1,1) = 0;

[Cx,Cy]=meshgrid(0:1:n,-n:1:n);
[xbunch,ybunch]=meshgrid(1/r:1/r:1);


%Generating Surface
Coef = Lh;
clear z; 
z = zeros(r,r); 
for i = 1:size(Cx,1)
    for j = 1:size(Cx,2)
        % disp([i j]); 
        z = z + Coef(i,j)*cos(2*pi*(Cx(i,j).*xbunch + Cy(i,j).*ybunch + Off(i,j)));
    end
end

%Normalizing surface
height=z-(max(max(z))+min(min(z)))/2;
maxh=max(max(height));
g=height/(maxh+0.01);

z = b*g;

%z=b*(g-min(min(height)));

% figure(1); clf; 
% hold on
% imagesc(linspace(0,L,L),linspace(0,L,L),-z)
% colormap(redblue)
% axis tight;
% axis square;
% hold off
end