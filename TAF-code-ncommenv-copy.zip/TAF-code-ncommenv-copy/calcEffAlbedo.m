function effAlbedo = calcEffAlbedo(z, melt_height, L, F0, kw, ki)
    water_depth = melt_height - z;
    tot = 0;
    for i = 1:L
        for j = 1:L
            if water_depth(i,j) == 0 % Unponded ice has albedo ~0.65
                a = 0.65;
            else % Calculate albedo of ponded ice
                a = getAlbedo(z(i,j), water_depth(i,j), F0, kw, ki);
            end
            if z == 0 % If there is no ice (open water), albedo ~0.08
                a = 0.08;
            end
            tot = tot + a;
        end
    end
    effAlbedo = tot/(L^2);
end