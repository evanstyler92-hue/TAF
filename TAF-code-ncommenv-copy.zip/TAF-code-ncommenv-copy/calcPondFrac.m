function pond_frac = calcPondFrac(z, melt_height, L)
    water_depth = melt_height - z; 
    count = 0; 
    for i = 1:L
        for j = 1:L
            if water_depth(i,j) > 0
                count = count + 1; 
            end
        end
    end
    pond_frac = count/(L^2);
end