function potential_e = calcPotential(local_min, melt, d, L)
    potential_e = 0; 
    for j = 1:L
        if d(j) ~= local_min(j)
            potential_e = potential_e + melt(j) - d(j);
        end
    end
end    