function potential_e = calcPotential3D(local_min, melt, z, L)
    potential_e = 0; 
    for i = 1:L
        for j = 1:L
            if (z(i, j) ~= local_min(i, j)) && (melt(i,j) - z(i,j) > 0.001)
                potential_e = potential_e + melt(i, j) - z(i, j);
            end
        end
    end
end 