function [avg_Albedo, pond_Frac] = calculate_pond_albedo(z, h, r, F0, kw, ki, b, bt)
%Calculates albedo and pond area fraction given an input surface and
%corresponding meltwater array.
sub_Albedo = 0;
sub_Frac = 0;
% volume = get_Volume(z,r,h);
% level = create_levelset(z,volume,r,b);
for i = 1:r % Piecewise calculation for albedo of surface
    for j = 1:r
         if z(i,j) <= -bt
             a = 0.05;
         elseif z(i,j) > -bt && h(i,j) <= 0.025
            a = 0.65; % If ice, albedo is ~0.65
         elseif z(i,j) > -bt && h(i,j) > 0.025
            a = getAlbedo(bt+z(i,j), h(i,j), F0, kw, ki);
            sub_Frac = sub_Frac + 1;
         end
         sub_Albedo = sub_Albedo + a;
    end 
end
pond_Frac = sub_Frac/(r^2);
avg_Albedo = sub_Albedo/(r^2); % Arithmetic average of albedo of surface
end