function [z, melt_height] = distribute(z, melt_height, L, b)
    top = circshift(z, [1 0]);
    bottom = circshift(z, [-1 0]);
    left = circshift(z, [0 1]);
    right = circshift(z, [0 -1]);
    
    % Identify extrema and saddle points
    [local_min, local_max, saddle_points] = idExtrema(z, left, right, top, bottom, L);
    
    % Send water to local minimums
    potential_e = calcPotential3D(local_min, melt_height, z, L); 
    iter = 0;
    while(potential_e > 0.01 && iter < 100)
        for n = 1:L
            for p = 1:L
                melt_height = moveToMins(z, local_max, local_min, saddle_points, top, bottom, left, right, n, p, melt_height);
            end
        end
        potential_e = calcPotential3D(local_min, melt_height, z, L);
        iter = iter + 1;
    end

    
    %Percolate water outwards from local minima
    bounded = isBounded3D(z, left, right, top, bottom, melt_height, L);
    iter2 = 0;
    while(bounded > b && iter2 < 100)
    for s = 1:L
        for t = 1:L
            melt_height = percolate(z, top, bottom, left, right, s, t, melt_height);
        end
    end
        bounded = isBounded3D(z, left, right, top, bottom, melt_height, L);
        iter2 = iter2 + 1;
    end
end