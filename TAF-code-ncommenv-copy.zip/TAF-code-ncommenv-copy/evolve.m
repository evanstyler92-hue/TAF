% Outputs new ice height and water height arrays without distribution
function [z, melt_height] = evolve(z, melt_height, dt, L, m_p, drain, m_i)
     %Setting constants for system
     p_ice = 900; % Ice density
     p_water = 1000; % Water density
     h_max = 0.1; % Maximum water depth for enhancement zone

     % Initialization
     water_depth = melt_height - z;
     melt_rate = zeros(L);
     drainage_rate = zeros(L);
        
     % Determine melt rate at each position
     for i = 1:L
         for j = 1:L
             if z(i,j) > 0 % As long as there is ice to melt
                 if water_depth(i,j) == 0 % Unponded ice
                     melt_rate(i,j) = m_i * dt;
                 elseif (water_depth(i,j) <= h_max) && (water_depth(i,j) > 0) % Enhancement zone
                     melt_rate(i,j) = m_i * (1 + m_p*(water_depth(i,j)/h_max)) * dt;
                     drainage_rate(i,j) = drain * dt; 
                 elseif water_depth(i,j) > h_max % Maximum melt rate
                     melt_rate(i,j) = m_i * (m_p+1) * dt;
                     drainage_rate(i,j) = drain * dt;
                 end
             else 
                 drainage_rate(i,j) = 0; 
                 melt_rate(i,j) = 0;
             end
         end
     end
%      avg_melt = sum(sum(melt_rate))/(L^2);
%      avg_drainage = sum(sum(drainage_rate))/(L^2);

     % Evolve ice height and water depth based on 
     for p = 1:L
         for q = 1:L
             z(p,q) = max(z(p,q) - melt_rate(p,q), 0);
             water_depth(p,q) = max(water_depth(p,q) + melt_rate(p,q)*(p_ice/p_water) - drainage_rate(p,q), 0);
         end
     end
     melt_height = z + water_depth;
end