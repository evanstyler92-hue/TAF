%Runs & plots albedo over time data for varied roughness (const. thickness)

%Initialize variables
T = 75; % Number of Days
M = 600; % Number of subintervals
b = [0.2,0.5,0.8];
bt = 2;
N = 1;

[Y,avgZ,avgH,avgA,avgP,avgR,E] = rough_thick(T,M,b,bt,N);

save('albedodata1.mat','bt','Y','avgA','avgP','avgR','E');
save('albedodata2.mat','avgZ','avgH');

c = 20;%Sparsifies plotted data
X = T/M:c*T/M:T;
X = [X T];
avgA = reshape(avgA,[3,size(avgA,3)]);
plot_A = zeros(3,size(X,2));
plot_A(:,1) = avgA(:,1);
plot_A(:,size(X,2)) = avgA(:,end);
for i = 2:size(X,2)
    plot_A(:,i) = avgA(:,c*(i-1));
end

figure(1);
clf
hold on
rectangle(Position=[50,0,25,0.65], FaceColor=[0.9 0.9 0.9], EdgeColor=[0.9 0.9 0.9])
hold on;  grid on;  grid minor
set(gca, "Layer", "top")
scatter(X,plot_A(1,:),50,'o','MarkerEdgeColor',[0.4660 0.6740 0.1880],'Linewidth',2);
scatter(X,plot_A(2,:),50,'x','MarkerEdgeColor',[0.8500 0.3250 0.0980],'Linewidth',2);
scatter(X,plot_A(3,:),50,'diamond','MarkerEdgeColor',[0.4940 0.1840 0.5560],'Linewidth',2);
xlabel('Time in Days')
ylabel('Albedo')
set(gca,'fontsize',14)
grid off
xlim([0,75])
ylim([0,0.65])
hold off