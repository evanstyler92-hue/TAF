%Runs averaging data for varying roughness and thickness, plots gradient
%plot and pdf plots

%Initialize variables
T = 50;
M = 600;
b = 0.1:0.1:1;
bt = 1:0.2:3;
N = 1;

%Generate data, comment out if data file is generated
run_roughthick(T,M,b,bt,N);
load('varydata1.mat');
load('varydata2.mat');
load('varydata3.mat');
plot_roughthick(K,J,bt,Y,E,t1,t2);