function albedo = getAlbedo(Hi, Hp, F0, kw, ki)
%Calculation of the albedo and transmittance of Arctic sea ice with melt pond on the top. 
%For more details of the algorothm, please see the paper:
%Peng Lu, Matti Lepp?ranta, Bin Cheng, Zhijun Li. 2016. Influence of melt-pond depth and ice thickness on Arctic sea-ice albedo and light transmittance. Cold Regions Science and Technology, doi:10.1016/j.coldregions.2015.12.010.
%Please cite this article if you use the code in your study.

%Definations of Input parameters:
%Scatterng coefficient of sea water rw (m-1)
rw = 0;
%Scattering coefficient of sea ice ri (m-1)
ri = 2.5;
%Reflectance on air-water interface R1
R1 = 0.05;
%Reflectance on water-air interface R11
R11 = (1-R1)/1.33^2;

%Optical properties of water
alpha_w = sqrt(kw./(kw+2.0*rw));
beta_w = sqrt(kw.*(kw+2.0*rw));
%Optical properties of ice
alpha_i = sqrt(ki./(ki+2.0*ri));
beta_i = sqrt(ki.*(ki+2.0*ri));


%Solutions for the equations
out = getC1234(alpha_i, beta_i, beta_w, R1, F0, Hi, Hp);
c1 = out(:,1);
c2 = out(:,2);

%Irradiance on air-pond interface Fp(z=0)
Fp_u1 = c1.*(1+alpha_w)+c2.*(1-alpha_w);

%Pond albedo
alpha_pond = (F0*R1+Fp_u1*(1-R11))./F0;
%Broad band albedo of melt pond
alpha_pond_T = sum(alpha_pond.*F0)/sum(F0);

albedo = alpha_pond_T;
end