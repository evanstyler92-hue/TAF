function out = getC1234(alpha_i, beta_i, beta_w, R1, F0, Hi, Hp)
%out = [c1, c2, c3, c4]
%Inputs£º
%alpha_i, beta_i, Optical properties of underlying ice 
%alpha_w, Optical properties of pond water
%R1, Reflectance on air-ice interface, =0.05
%F0, Incident solar irradiance
%Hi, Thickness of underlying ice, m
%Hp, Pond depth, m

%For more details of the algorothm, please see the paper:
%Peng Lu, Matti Lepp?ranta, Bin Cheng, Zhijun Li. 2016. Influence of melt-pond depth and ice thickness on Arctic sea-ice albedo and light transmittance. Cold Regions Science and Technology, doi:10.1016/j.coldregions.2015.12.010.
%Please cite this article if you use the code in your study.

%Reflectance for water-leaving radiation
R11 = (1-R1)/1.33^2;

%c3 is firstly calculated
temp1 = F0.*(1-R1).*exp(-1.0*beta_w*Hp);
temp2 = (1+alpha_i).^2.*exp(2.0*beta_i*Hi)./(1-alpha_i);
temp3 = R11*(1+alpha_i).*(1-exp(2.0*beta_i*Hi)).*exp(-2.0*beta_w*Hp);
c3 = temp1./(1-alpha_i-temp2-temp3);

%c4
c4 = -1.0*(1+alpha_i).*exp(2.0*beta_i*Hi).*c3./(1-alpha_i);

%c1
c1 = 0.5*(1+alpha_i).*(1-exp(2.0*beta_i*Hi)).*exp(-1.0*beta_w*Hp).*c3;

%c2
c2 = 0.5*F0*(1-R1)+R11*c1;

out = [c1, c2, c3, c4];
end