function surf_rough = getSurf_Rough(z, L)

tot = sum(sum(z));
mean = tot/(L*L);
tot = trapz(1:L, trapz(1:L, abs(z - mean)));
surf_rough = tot/(L*L);
end