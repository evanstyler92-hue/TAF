function [local_min, local_max, saddle_points] = idExtrema(z, left, right, top, bottom, L)
local_min = zeros(L);
local_max = zeros(L);
saddle_points = zeros(L);
    for i = 1:L
    for j = 1:L
        pos = z(i, j);
        pos_top = top(i, j);
        pos_bottom = bottom(i, j);
        pos_left = left(i, j);
        pos_right = right(i, j);
        sorted = sort([pos, pos_top, pos_bottom, pos_left, pos_right]);
        % If local max
        if sorted(5) == pos
            local_max(i, j) = pos;
        % If local min    
        elseif sorted(1) == pos
            local_min(i, j) = pos; 
        elseif sorted(3) == pos && ((min(pos_top, pos_bottom) > max(pos_left,pos_right)) || (max(pos_top, pos_bottom) < min(pos_left,pos_right)))      
            saddle_points(i, j) = pos;
        end    
    end
    end
end