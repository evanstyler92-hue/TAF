function bounded = isBounded(d, left, right, melt, L) % Not right
    bounded = 0;
    melt_r = circshift(melt, -1);
    melt_l = circshift(melt, 1); 
    for i = 1:L
        if d(i) ~= melt(i)
            if (left(i) ~= melt_l(i)) && (right(i) ~= melt_r(i)) 
                if (abs(melt(i) - melt_r(i)) > 0) || (abs(melt(i) - melt_l(i)) > 0) 
                    bounded = bounded + max(abs(melt(i) - melt_r(i)), abs(melt(i) - melt_l(i)));
                end
            elseif (left(i) ~= melt_l(i)) && (right(i) == melt_r(i))    
                if (abs(melt(i) - melt_l(i)) > 0)
                    bounded = bounded + abs(melt(i) - melt_l(i));
                end
            elseif (right(i) ~= melt_r(i)) && (left(i) == melt_l(i))
                if (abs(melt(i) - melt_l(i)) > 0)
                    bounded = bounded + abs(melt(i) - melt_r(i));
                end
            end    
        end
    end    
end    