function bounded = isBounded3D(z, left, right, top, bottom, melt, L) % Not right
    bounded = 0;
    melt_t = circshift(melt, [1 0]);
    melt_b = circshift(melt, [-1 0]);
    melt_l = circshift(melt, [0 1]);
    melt_r = circshift(melt, [0 -1]);
    for i = 1:L
        for j = 1:L
            if z(i, j) ~= melt(i, j)
                 dif_top = max(melt(i,j) - top(i,j), 0);
                 dif_bottom = max(melt(i,j) - bottom(i,j), 0);
                 dif_left = max(melt(i,j) - left(i,j), 0);
                 dif_right = max(melt(i,j) - right(i,j), 0);

                 bounded = bounded + dif_top*(abs(melt(i,j) - melt_t(i,j)))...
                                   + dif_bottom*(abs(melt(i,j) - melt_b(i,j)))... 
                                   + dif_left*(abs(melt(i,j) - melt_l(i,j)))...
                                   + dif_right*(abs(melt(i,j) - melt_r(i,j)));
            end
        end       
    end    
end  