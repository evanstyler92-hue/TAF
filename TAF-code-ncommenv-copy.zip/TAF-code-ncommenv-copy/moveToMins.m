function melt = moveToMins(z, local_max, local_min, saddle_points, top, bottom, left, right, n, p, melt)
    melt_t = circshift(melt, [1 0]);
    melt_b = circshift(melt, [-1 0]);
    melt_l = circshift(melt, [0 1]);
    melt_r = circshift(melt, [0 -1]);
    % If water isn't on a minimum, move it towards one
    if z(n,p) ~= melt(n,p) && z(n,p) ~= local_min(n,p)
        if z(n, p) == local_max(n, p) % Pos is local max
            prob = randsample(4, 1);
            if prob == 1 % Go top
                melt_t(n, p) = melt_t(n, p) + melt(n, p) - z(n, p);
                melt = circshift(melt_t, [-1 0]);
                melt(n, p) = z(n, p);        
            elseif prob == 2 % Go bottom
                melt_b(n, p) = melt_b(n, p) + melt(n, p) - z(n, p);
                melt = circshift(melt_b, [1 0]);
                melt(n, p) = z(n, p);
            elseif prob == 3 % Go left
                melt_l(n, p) = melt_l(n, p) + melt(n, p) - z(n, p);
                melt = circshift(melt_l, [0 -1]);
                melt(n, p) = z(n, p);
            else % Go right
                melt_r(n, p) = melt_r(n, p) + melt(n, p) - z(n, p);
                melt = circshift(melt_r, [0 1]);
                melt(n, p) = z(n, p);
            end     
        elseif z(n, p) == saddle_points(n, p)% Pos is saddle
            prob = rand;
            if top(n,p) > left(n,p) % Left/right are low points
                if prob > 0.5 % Go left
                    melt_l(n, p) = melt_l(n, p) + melt(n, p) - z(n, p);
                    melt = circshift(melt_l, [0 -1]);
                    melt(n, p) = z(n, p);
                else % Go right
                    melt_r(n, p) = melt_r(n, p) + melt(n, p) - z(n, p);
                    melt = circshift(melt_r, [0 1]);
                    melt(n, p) = z(n, p);
                end
            else % Top/bottom are low points 
                if prob > 0.5 % Go Top
                    melt_t(n, p) = melt_t(n, p) + melt(n, p) - z(n, p);
                    melt = circshift(melt_t, [-1 0]);
                    melt(n, p) = z(n, p);
                else % Go bottom
                    melt_b(n, p) = melt_b(n, p) + melt(n, p) - z(n, p);
                    melt = circshift(melt_b, [1 0]);
                    melt(n, p) = z(n, p);
                end
            end
        else % Pos is not an extrema
            min_neighbor = min([top(n, p), bottom(n, p), left(n, p), right(n, p)]);
            if min_neighbor == top(n, p) % If lowest nearest point is top, go top
                melt_t(n, p) = melt_t(n, p) + melt(n, p) - z(n, p);
                melt = circshift(melt_t, [-1 0]);
                melt(n, p) = z(n, p);
            elseif min_neighbor == bottom(n, p) % If lowest nearest point is bottom, go bottom
                melt_b(n, p) = melt_b(n, p) + melt(n, p) - z(n, p);
                melt = circshift(melt_b, [1 0]);
                melt(n, p) = z(n, p);
            elseif min_neighbor == left(n, p) % If lowest nearest point is left, go left
                melt_l(n, p) = melt_l(n, p) + melt(n, p) - z(n, p);
                melt = circshift(melt_l, [0 -1]);
                melt(n, p) = z(n, p);
            elseif min_neighbor == right(n,p) % If lowest nearest point is right, go right
                melt_r(n, p) = melt_r(n, p) + melt(n, p) - z(n, p);
                melt = circshift(melt_r, [0 1]);
                melt(n, p) = z(n, p);
            end
        end    
    end
end


