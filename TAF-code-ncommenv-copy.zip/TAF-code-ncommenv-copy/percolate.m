function melt = percolate(z, top, bottom, left, right, s, t, melt)
        melt_t = circshift(melt, [1 0]);
        melt_b = circshift(melt, [-1 0]);
        melt_l = circshift(melt, [0 1]);
        melt_r = circshift(melt, [0 -1]);
        if z(s, t) ~= melt(s, t)
            meltHeight_min = min([melt_t(s,t), melt_b(s,t), melt_l(s,t), melt_r(s,t), melt(s,t)]);
            if meltHeight_min ~= melt(s,t)
                if (melt_t(s,t) == meltHeight_min)
                    tot = melt_t(s,t) + melt(s,t) - z(s,t) - top(s,t);
                    dif = abs(z(s,t) - top(s,t));
                    if tot <= dif
                        if z(s,t) < top(s,t)
                            melt_t(s,t) = top(s,t);    
                            melt = circshift(melt_t, [-1 0]);
                            melt(s,t) = z(s,t) + tot;
                        else 
                            melt_t(s,t) = top(s,t) + tot;
                            melt = circshift(melt_t, [-1 0]);
                            melt(s,t) = z(s,t);
                        end
                    else
                        avg = (tot - dif)/2;
                        h = max(z(s,t), top(s,t)) + avg;
                        melt_t(s,t) = h;
                        melt = circshift(melt_t, [-1 0]);
                        melt(s,t) = h;
                    end
                elseif (melt_b(s,t) == meltHeight_min)
                    tot = melt_b(s,t) + melt(s,t) - z(s,t) - bottom(s,t);
                    dif = abs(z(s,t) - bottom(s,t));
                    if tot <= dif
                        if z(s,t) < bottom(s,t)
                            melt_b(s,t) = bottom(s,t);
                            melt = circshift(melt_b, [1 0]);
                            melt(s,t) = z(s,t) + tot;
                        else 
                            melt_b(s,t) = bottom(s,t) + tot;
                            melt = circshift(melt_b, [1 0]);
                            melt(s,t) = z(s,t);
                        end
                    else
                        avg = (tot - dif)/2;
                        h = max(z(s,t), bottom(s,t)) + avg;
                        melt_b(s,t) = h;
                        melt = circshift(melt_b, [1 0]);
                        melt(s,t) = h;
                    end
                elseif (melt_l(s,t) == meltHeight_min)
                    tot = melt_l(s,t) + melt(s,t) - z(s,t) - left(s,t);
                    dif = abs(z(s,t) - left(s,t)); 
                    if tot <= dif
                        if z(s,t) < left(s,t)
                            melt_l(s,t) = left(s,t);
                            melt = circshift(melt_l, [0 -1]);
                            melt(s,t) = z(s,t) + tot;
                        else 
                            melt_l(s,t) = left(s,t) + tot;
                            melt = circshift(melt_l, [0 -1]);
                            melt(s,t) = z(s,t);
                        end
                    else
                        avg = (tot - dif)/2;
                        h = max(z(s,t), left(s,t)) + avg;
                        melt_l(s,t) = h;
                        melt = circshift(melt_l, [0 -1]);
                        melt(s,t) = h;
                    end
                elseif (melt_r(s,t) == meltHeight_min)
                    tot = melt_r(s,t) + melt(s,t) - z(s,t) - right(s,t);
                    dif = abs(z(s,t) - right(s,t)); 
                    if tot <= dif
                        if z(s,t) < right(s,t)
                            melt_r(s,t) = right(s,t);
                            melt = circshift(melt_r, [0 1]);
                            melt(s,t) = z(s,t) + tot;
                        else 
                            melt_r(s,t) = right(s,t) + tot;
                            melt = circshift(melt_r, [0 1]);
                            melt(s,t) = z(s,t);
                        end
                    else
                        avg = (tot - dif)/2;
                        h = max(z(s,t), right(s,t)) + avg;
                        melt_r(s,t) = h;
                        melt = circshift(melt_r, [0 1]);
                        melt(s,t) = h;
                    end
                end
            end
        end
end