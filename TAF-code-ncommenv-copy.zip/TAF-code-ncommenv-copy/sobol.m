function [pd1,pd2,t1,t2,S1,S2] = sobol(X,Y,E,p,q,b1,b2)
% function [S1,S2] = sobol(X,Y,E)
%SOBOL Calculates first-order Sobol indices assuming uniform distribution
%for parameters
%   Inputs:
%   X := 1xJ starting base thickness array
%   Y := 1xK average roughness array at time t=1
%   E := KxJ total absorbed energy array
%   p := mean, s.d. for thickness
%   q := mean, s.d. for roughness
%   b1 := bounds for truncation for thickness
%   b2 := bounds for truncation for roughness
%   Outputs:
%   S1 := 1st-order sensitivity index, for thickness
%   S2 := 1st-order sensitivity index, for roughness

K = size(Y,2);
J = size(X,2);

f1 = zeros(1,K);
f2 = zeros(1,J);
V1 = 0;
V2 = 0;

% Assumption: X,Y uniform RV
% f0 = sum(sum(E))/(K*J);
% for i = 1:K
%     f1(i) = sum(E(i,:))/J - f0;
%     V1 = V1 + f1(i)^2/K;
% end
% for j = 1:J
%     f2(j) = sum(E(:,j))/K - f0;
%     V2 = V2 + f2(j)^2/J;
% end
% 
% V = sum(sum((E-f0).^2))/(K*J);

%Assumption: X,Y normal RV
[pd1,pd2,t1,t2,u,v] = trunc_normal(X,Y,p,q,b1,b2);
size(u)
size(v)
size(E)

f0 = v*E*u';

%Row variance (roughness influence)
for i = 1:K
    f1(i) = E(i,:)*u' - f0;
    V1 = V1 + v(i)*f1(i)^2;
end

%Column variance (thickness influence)
for j = 1:J
    f2(j) = v*E(:,j) - f0;
    V2 = V2 + u(j)*f2(j)^2;
end

V = v*(E-f0).^2*u';

S1 = V1/V;
S2 = V2/V;

end