function [pd1,pd2,t1,t2,u,v] = trunc_normal(X,Y,p,q,b1,b2)
%TRUNC_NORMAL Generates weights for truncated normals
%   Inputs:
%   X := 1xJ array for thickness
%   Y := 1xK array for roughness
%   p := mean, s.d. for thickness
%   q := mean, s.d. for roughness
%   b1 := bounds for truncation for thickness
%   b2 := bounds for truncation for roughness
%   Outputs:
%   u := weights for thickness
%   v := weights for roughness

J = size(X,2);
K = size(Y,2);

pd1 = makedist('Normal','mu',p(1),'sigma',p(2));
pd2 = makedist('Normal','mu',q(1),'sigma',q(2));

t1 = truncate(pd1,b1(1),b1(2));
t2 = truncate(pd2,b2(1),b2(2));

u = zeros(1,J);
v = zeros(1,K);

format long;
u(1) = cdf(t1,(X(1)+X(2))/2);
v(1) = cdf(t2,(Y(1)+Y(2))/2);
% u(1) = cdf(t1,X(1));
% v(1) = cdf(t2,Y(1));
for i = 2:J-1
    u(i) = cdf(t1,(X(i)+X(i+1))/2)-cdf(t1,(X(i-1)+X(i))/2);
%     u(i) = cdf(t1,X(i))-cdf(t1,X(i-1));
end
for i = 2:K-1
    v(i) = cdf(t2,(Y(i)+Y(i+1))/2)-cdf(t2,(Y(i-1)+Y(i))/2);
%     v(i) = cdf(t2,Y(i))-cdf(t2,Y(i-1));
end
u(J) = cdf(t1,X(J)) - cdf(t1,(X(J-1)+X(J))/2);
v(K) = cdf(t2,Y(K)) - cdf(t2,(Y(K-1)+Y(K))/2);

end