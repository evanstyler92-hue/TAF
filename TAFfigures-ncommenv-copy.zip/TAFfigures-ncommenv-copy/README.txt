The various "playswithfigs___.m" files are used to produce the figures from the manuscript.
To reproduce all of the figures from the manuscript, you can generate the data using the provided run_model.m code,
or you can find all of the final data here:

https://drive.google.com/drive/folders/13fFhHlzhJLV_fG2HH1GsPQDwxtfJB9pa?usp=sharing

After copying these .mat files into the folder containing the plotting scripts, everything should run.